//Author : Azab Mariam Ossama Elshafei Abdelrh
//Neptun Id : PIALJV

#include <iostream>
#include "xmatrix.h"

using namespace std;

int main()
{
try{

    xmatrix a;
    cout << "a:\n" << a<< endl << endl;

    //cout << "element[0,0] of a :" << a.getElem(0,0) <<endl << endl;
    //cout << "element[0,1] of a :" << a.getElem(0,1) <<endl << endl;
     //cout << "element[0,2] of a :" << a.getElem(0,2) <<endl << endl;
      //cout << "element[1,0] of a :" << a.getElem(1,0) <<endl << endl;
       //cout << "element[1,1] of a :" << a.getElem(1,1) <<endl << endl;
        //cout << "element[1,2] of a :" << a.getElem(1,2) <<endl << endl;
         //cout << "element[2,0] of a :" << a.getElem(2,0) <<endl << endl;
          //cout << "element[2,1] of a :" << a.getElem(2,1) <<endl << endl;
           //cout << "element[2,2] of a :" << a.getElem(2,2) <<endl << endl;

          /* cout << "element[8,9]: "<< a.getElem(8,9) <<endl ;
    vector <int> mytry ={1,2,3,4,5};
    xmatrix b(mytry);
    cout << "b:\n" << b << endl;
    cout << "element[2,2] of b :" << a.getElem(2,2) <<endl << endl;*/

    //xmatrix c("input.txt");
    //cout << "c:\n" << c<< endl << endl;
    //cout << "element[2,2] of c:" << a.getElem(2,2) <<endl << endl;


   try {
        cout << "sum:\n" << xmatrix::adding(a,b) << endl << endl;
   }
    catch (xmatrix::DimensionMismatchException ex)
    {
        cout << "exception caught" << endl << endl;
    }
    /* {
        cout << "multiply:\n" << xmatrix::multiplying(a,b) << endl << endl;
   }
    catch (xmatrix::DimensionMismatchException ex)
    {
        cout << "exception caught" << endl << endl;
    }*/
}
catch (xmatrix::ZeroentrieExeption ex ){
cout << " can't have zero entries" <<endl;
}
catch (xmatrix::InvalidIndexException e){

cout << "invalid index " <<endl;
}
    return 0;
}
