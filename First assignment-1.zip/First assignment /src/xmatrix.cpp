//Author : Azab Mariam Ossama Elshafei Abdelrh
//Neptun Id : PIALJV

#include "xmatrix.h"
#include<vector>
using namespace std;

// initial constructor
//Task : initialize the size and values of the matrix
//input:none
xmatrix::xmatrix()
{
  x_size = 3 ;
  x_vec ={1,2,3,4,5};

}
// initial constructor by given vector
// task : initialize the matrix by the given vector
// input : vector
xmatrix::xmatrix(const std::vector <int> & vec){
for (int i =0 ; i < vec.size() ; i++){
    if(vec[i]==0)
        throw ZeroentrieExeption() ;
}
setVec(vec);

}
//initial constructor by the matrix size given
//input integer size
//task : clarify the relation between the size of the vector and the size of the matrix
xmatrix::xmatrix(int size){

    x_size = size ;


    if(size%2==0)
        x_vec.resize(size*2);
    else
      {

        x_vec.resize((size*2)-1);}


}

//initial constructor by file name
//task : get values of the vector from input file
//input : string filename
xmatrix::xmatrix(const std::string& fname){
    std :: fstream f(fname);
    if(f.fail())
    {
        x_size = 0 ;
        x_vec.clear();

    }
    else {
        int e ;
        while(f >> e )
        {
                if (e==0)
                    throw ZeroentrieExeption() ;

                x_vec.push_back(e);

        }
        double n = mymatrixsize(x_vec.size());
        if(n==floor(n)){
            x_size= n ;
        }
        else {
            x_size =0 ;
            x_vec.clear();
        }
    }
}


//task : get the index of the vector
//input : indexes of the matrix
//output : the opposite index of the vector
int xmatrix::index(int i , int j) const {
if (x_size % 2 == 0){
if(i==j)
    {
        return (i+j);

        }

else
{
    return (i*2)+1;

}
}
else {
    if(i==j)
        return i+j ;
    else if ( i < j)
        return (i*2)+1;
    else
        return (i*2)-1;

}}

//task: get size of matrix from the vector size
//input : integer size of the vector
//output : size of the matrix
double xmatrix:: mymatrixsize (unsigned int size){
    if (size%2==0)
        return size/2;
    else
        return (size+1)/2;

}

bool xmatrix::inside(int i , int j ) const {
return (i==j || (i+j)==(x_size-1)); }


int xmatrix::getElem(int i , int j ) const {
if (inside(i,j)){
    return x_vec[index(i,j)];
}
else if (!inside(i,j) && i<x_size && j<x_size)
    return 0;
else
    throw InvalidIndexException();
}

void xmatrix::setVec(const vector<int>& _vec){
double n = mymatrixsize(_vec.size());
if (n==floor(n))
    {
        x_size = n ;
        x_vec = _vec ;
    }

else{
    throw InvalidIndexException();
}
}
void xmatrix::setElem(int i , int j , int e){
if  ( (i==j || (i+j)==(x_size-1)))
{

        x_vec[index(i,j)] = e;
}


else {
    throw OutOFXmatrixException();
}

}

xmatrix xmatrix::adding(const xmatrix& a , const xmatrix& b){
if(a.getSize()==b.getSize()){
    xmatrix sum(a);
    for(int i =0 ; i <= a.x_vec.size();i++){
        sum.x_vec[i] += b.x_vec[i];
    }
    return sum ;
}
else {
    throw DimensionMismatchException();
}
}
xmatrix xmatrix::multiplying(const xmatrix& a , const xmatrix& b){
if (a.getSize() == b.getSize())
    {
        xmatrix mul(a.getSize()); /// creating a matrix filled with 0 of the same size like a
        for (int i=0;i<a.x_size;i++)
        {
            for (int j=0;j<a.x_size;j++)
            {
                if (a.inside(i,j))
                {
                    for (int k=0;k<a.x_size;k++)
                    {
                        mul.setElem(i,j,mul.getElem(i,j)+a.getElem(i,k)*b.getElem(k,j));
                    }
                }
            }
        }
        return mul;
    }
    else
    {
        throw DimensionMismatchException();
    }
}



std::ostream &operator<<(std::ostream &os,const xmatrix& x) ///overriding the << operator to be able to output a matrix!
{
    os << x.x_size <<"x"<<x.x_size<<std::endl;
    for (int i=0;i<x.x_size;++i)
    {
        for (int j=0;j<x.x_size;++j)
        {
            os << x.getElem(i,j) << " ";
        }
        os << std::endl;
    }
    return os;
}










