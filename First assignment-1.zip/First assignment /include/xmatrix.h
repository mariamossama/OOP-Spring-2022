//Author : Azab Mariam Ossama Elshafei Abdelrh
//Neptun Id : PIALJV
#pragma once
#include<vector>
#include<string>
#include<fstream>
#include<math.h>
using namespace std ;

class xmatrix
{
    private:
            int x_size ; //size of  the matrix x_size*x_size
            vector <int> x_vec ;

            int index(int i , int j) const ;
            double mymatrixsize (unsigned int size); //from vector length
            bool inside(int i , int j ) const ;


    public:
        class InvalidIndexException : public exception{};
        class InvalidInputException : public exception{};
        class OutOFXmatrixException : public exception{};
        class DimensionMismatchException : public exception{};
        class ZeroentrieExeption : public exception{};

        xmatrix();
        xmatrix(int size );
        xmatrix(const std::string&fname);
        xmatrix(const std::vector <int> & vec);


        int getSize()const {return x_size;} //size of the matrix
        int getElem(int i , int j ) const ; //get element from the matrix

        void setVec(const std::vector<int>& _vec);
        void setElem(int i , int j , int e);

        static xmatrix adding(const xmatrix& a , const xmatrix& b );
        static xmatrix multiplying(const xmatrix& a , const xmatrix& b);

        friend std::ostream &operator<<(std::ostream &os, const xmatrix& x);



};


